package com.example.restapi;


import java.util.List;
import java.util.concurrent.Callable;

import retrofit2.Call;
import retrofit2.http.GET;

public interface myapi {
 @GET("posts")
 Call<List<model>> getmodel();

}
